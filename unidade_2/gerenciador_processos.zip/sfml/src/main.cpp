#include <SFML/Graphics.hpp>
#include <stdio.h>      
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <math.h>
#include <sys/resource.h>
#include <sched.h>

int DELAY_SEGS = 1;
int SELECTED_ID = -1;
std::string CURR_FILTER = "";

char* getProgs(){
    if (CURR_FILTER.empty()){
        system("ps -eo fname,pid,pcpu,ppid,pri,s | (head -1 && tail -18) > pid.txt");
    } else {
        std::string cmd = "ps -eo fname,pid,pcpu,ppid,pri,s | (head -1 && grep " + CURR_FILTER + ") > pid.txt";
        //std::cout<<cmd<<std::endl;
        system(cmd.c_str());
    }
    
    char * buffer = 0;
    long length;
    FILE * f = fopen ("pid.txt", "rb");

    if (f)
    {
        fseek (f, 0, SEEK_END);
        length = ftell (f);
        fseek (f, 0, SEEK_SET);
        buffer = (char*)malloc(length);
        if (buffer)
            fread (buffer, 1, length, f);
        fclose (f);
    }
    return buffer;
}

void kill_process(int pid)
{
    std::cout<<"Killing process with PID: "<<pid<<std::endl;
    kill(pid, SIGKILL);
    //printf("Processo finalizado!!!\n");
};

void stop_process(int pid)
{
    std::cout<<"Stopping process with PID: "<<pid<<std::endl;
    kill(pid, SIGSTOP);
    //printf("Processo parado!!!\n");
};

void resume_process(int pid)
{
    std::cout<<"Resuming process with PID: "<<pid<<std::endl;
    kill(pid, SIGCONT);
    //printf("Processo continuado!!!\n");
};

void set_cpu(int pid, int cpu)
{
    cpu_set_t mask;
    CPU_SET(cpu, &mask);
    std::cout<<"Setting CPU "<< cpu <<" to process with PID: "<<pid<<std::endl;
    int result = sched_setaffinity(pid, sizeof(mask), &mask);
};
    
void set_priority(int pid, int priority)
{
    std::cout<<"Setting priority "<< priority <<" to process with PID: "<<pid<<std::endl;
    setpriority(PRIO_PROCESS, pid, priority);
};

void set_filter(std::string filter){
    std::cout<<"Setting new filter "<< filter;
    CURR_FILTER = filter;
}

int main()
{
    sf::RenderWindow window(sf::VideoMode(600, 400), "HTOP Clone");

    /////////////////// TIMER VARIABLES

    struct timeval tempo_inicial, tempo_final;
    int tmicro = 0;
    int delay_usegs = DELAY_SEGS*1000000;

    /////////////////// INTERFACE VARIABLES

    sf::Font font;
    font.loadFromFile("/home/tiago/Downloads/sfml/fonts/arial_narrow_7.ttf");
    float px = 360.f;
    float py = 40.f;
    float hpadding = 5.f;
    float vpadding = 30.f;
    float backpadding = 50.f;
    float forwardpadding = 30.f;
    float boxh = 20.f;
    float boxw = 180.f;
    int font_size = 20;

    sf::Text text;

    /////////////////// PID BOX

    sf::RectangleShape PIDBox;
    PIDBox.setSize(sf::Vector2f(boxw, boxh));
    PIDBox.setOutlineColor(sf::Color::Red);
    PIDBox.setPosition(px + forwardpadding, py + vpadding * 0);

    sf::String PIDInput;
    sf::Text PIDText;
    PIDText.setFont(font);
    PIDText.setColor(sf::Color::Black);
    PIDText.setCharacterSize(12);
    PIDText.setPosition(px + forwardpadding + hpadding, py + vpadding * 0);

    sf::Text PIDLabel;
    PIDLabel.setString("PID:");
    PIDLabel.setFont(font);
    PIDLabel.setColor(sf::Color::White);
    PIDLabel.setCharacterSize(font_size);
    PIDLabel.setPosition(px - backpadding, py + vpadding * 0 - 3);

    /////////////////// PRIORITY BOX

    sf::RectangleShape PriorityBox;
    PriorityBox.setSize(sf::Vector2f(boxw, boxh));
    PriorityBox.setOutlineColor(sf::Color::Red);
    PriorityBox.setPosition(px + forwardpadding, py + vpadding * 1);

    sf::String PriorityInput;
    sf::Text PriorityText;
    PriorityText.setFont(font);
    PriorityText.setColor(sf::Color::Black);
    PriorityText.setCharacterSize(12);
    PriorityText.setPosition(px + forwardpadding + hpadding, py + vpadding * 1);

    sf::Text PriorityLabel;
    PriorityLabel.setString("PRIO:");
    PriorityLabel.setFont(font);
    PriorityLabel.setColor(sf::Color::White);
    PriorityLabel.setCharacterSize(font_size);
    PriorityLabel.setPosition(px - backpadding, py + vpadding * 1 - 3);

    /////////////////// CPU BOX

    sf::RectangleShape CPUBox;
    CPUBox.setSize(sf::Vector2f(boxw, boxh));
    CPUBox.setOutlineColor(sf::Color::Red);
    CPUBox.setPosition(px + forwardpadding, py + vpadding * 2);

    sf::String CPUInput;
    sf::Text CPUText;
    CPUText.setFont(font);
    CPUText.setColor(sf::Color::Black);
    CPUText.setCharacterSize(12);
    CPUText.setPosition(px + forwardpadding + hpadding, py + vpadding * 2);

    sf::Text CPULabel;
    CPULabel.setString("CPU:");
    CPULabel.setFont(font);
    CPULabel.setColor(sf::Color::White);
    CPULabel.setCharacterSize(font_size);
    CPULabel.setPosition(px - backpadding, py + vpadding * 2 - 3);

    /////////////////// FILTER BOX

    sf::RectangleShape FilterBox;
    FilterBox.setSize(sf::Vector2f(boxw, boxh));
    FilterBox.setOutlineColor(sf::Color::Red);
    FilterBox.setPosition(px + forwardpadding, py + vpadding * 3);

    sf::String FilterInput;
    sf::Text FilterText;
    FilterText.setFont(font);
    FilterText.setColor(sf::Color::Black);
    FilterText.setCharacterSize(12);
    FilterText.setPosition(px + forwardpadding + hpadding, py + vpadding * 3);

    sf::Text FilterLabel;
    FilterLabel.setString("FILTER:");
    FilterLabel.setFont(font);
    FilterLabel.setColor(sf::Color::White);
    FilterLabel.setCharacterSize(font_size);
    FilterLabel.setPosition(px - backpadding, py + vpadding * 3 - 3);

    /////////////////// INSTRUCTIONS

    sf::Text InstructionsText;
    InstructionsText.setString("Press:\n\nK - Kill a process\nS - Stop a process\nR - Resume a process\nP - Set priority\nC - Set cpu\nF - Apply filter");
    InstructionsText.setFont(font);
    InstructionsText.setColor(sf::Color::White);
    InstructionsText.setCharacterSize(font_size - 2);
    InstructionsText.setPosition(px - hpadding, py + vpadding * 5 - 3);

    while (window.isOpen())
    {

        gettimeofday(&tempo_inicial, NULL);

        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            
            // Handle text box input
            if (event.type == sf::Event::TextEntered)
            {
                if (SELECTED_ID >= 0){
                    switch (SELECTED_ID)
                    {
                        case 0:
                            if (event.text.unicode == 8){
                                if (PIDInput.getSize() > 0)
                                    PIDInput.erase(PIDInput.getSize() - 1,1);
                            } else  PIDInput += event.text.unicode;
                            PIDText.setString(PIDInput);
                            break;

                        case 1:
                            if (event.text.unicode == 8){
                                if (PriorityInput.getSize() > 0)
                                    PriorityInput.erase(PriorityInput.getSize() - 1,1);
                            } else  PriorityInput += event.text.unicode;
                            PriorityText.setString(PriorityInput);
                            break;

                        case 2:
                            if (event.text.unicode == 8){
                                if (CPUInput.getSize() > 0)
                                    CPUInput.erase(CPUInput.getSize() - 1,1);
                            } else  CPUInput += event.text.unicode;
                            CPUText.setString(CPUInput);
                            break;

                        case 3:
                            if (event.text.unicode == 8){
                                if (FilterInput.getSize() > 0)
                                    FilterInput.erase(FilterInput.getSize() - 1,1);
                            } else  FilterInput += event.text.unicode;
                            FilterText.setString(FilterInput);
                            break;
                        
                        default:
                            break;
                    } 
                } 
                
            }
            
            // Handle key events
            if (event.type == sf::Event::KeyPressed)
            {
                if (SELECTED_ID < 0) {
                    std::string pid_string = PIDInput.toAnsiString();

                    if(!pid_string.empty())
                    {
                        int pid = std::stoi(pid_string);
                        if (event.key.code == sf::Keyboard::K) kill_process(pid);
                        if (event.key.code == sf::Keyboard::S) stop_process(pid);
                        if (event.key.code == sf::Keyboard::R) resume_process(pid);
                        
                        if (event.key.code == sf::Keyboard::P)
                        {
                            std::string priority_string = PriorityInput.toAnsiString();
                            int priority = std::stoi(priority_string);
                            set_priority(pid, priority);
                        }
                        if (event.key.code == sf::Keyboard::C)
                        {
                            std::string cpu_string = CPUInput.toAnsiString();
                            int cpu = std::stoi(cpu_string);
                            set_cpu(pid, cpu);
                        }
                    }
                    
                    if (event.key.code == sf::Keyboard::F)
                    {
                        std::string filter_string = FilterInput.toAnsiString();
                        set_filter(filter_string);
                    }
                }
            }

            if (event.type == sf::Event::MouseButtonReleased) 
            {
                int x = sf::Mouse::getPosition(window).x;
                int y = sf::Mouse::getPosition(window).y;

                if(y < py || y > py + 4*vpadding )  SELECTED_ID = -1;
                if(y > py && y < py + vpadding) SELECTED_ID = 0;
                if(y > py + vpadding && y < py  + 2*vpadding) SELECTED_ID = 1;
                if(y > py + 2*vpadding && y < py + 3*vpadding) SELECTED_ID = 2;
                if(y > py +  3*vpadding && y < py + 4*vpadding) SELECTED_ID = 3;

                std::cout<< SELECTED_ID<<std::endl;

                PIDBox.setOutlineThickness(0);
                PriorityBox.setOutlineThickness(0);
                CPUBox.setOutlineThickness(0);
                FilterBox.setOutlineThickness(0);
                
                switch (SELECTED_ID)
                {
                    case 0:
                        PIDBox.setOutlineThickness(2);
                        break;
                    case 1:
                        PriorityBox.setOutlineThickness(2);
                        break;
                    case 2:
                        CPUBox.setOutlineThickness(2);
                        break;
                    case 3:
                        FilterBox.setOutlineThickness(2);
                        break;
                    default:
                        break;
                }
            }
        }

        window.clear();
        window.draw(text);

        window.draw(PIDBox);
        window.draw(PriorityBox);
        window.draw(CPUBox);
        window.draw(FilterBox);

        window.draw(PIDText);
        window.draw(PriorityText);
        window.draw(CPUText);
        window.draw(FilterText);

        window.draw(PIDLabel);
        window.draw(PriorityLabel);
        window.draw(CPULabel);
        window.draw(FilterLabel);

        window.draw(InstructionsText);

        window.display();

        gettimeofday(&tempo_final, NULL);

        if(tempo_inicial.tv_usec > tempo_final.tv_usec)
             tmicro += (tempo_final.tv_usec + 1000000 - tempo_inicial.tv_usec);
        else tmicro += (tempo_final.tv_usec - tempo_inicial.tv_usec);

        if (tmicro > delay_usegs){

            tmicro = 0;
            //printf("TIME\n");
            char * progs = 0;
            progs = getProgs();
            text.setString(progs);
            text.setFont(font);
            text.setCharacterSize(font_size);
            text.setPosition(10.f, 5.f);

        }
        
    }

    return 0;
}
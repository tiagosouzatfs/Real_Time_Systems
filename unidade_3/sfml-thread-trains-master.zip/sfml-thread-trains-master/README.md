# SFML Thread Trains
Atividade da terceira avaliação do curso de Sistemas em tempo real da UFRN (07/2022)
By Angelo Leite e Tiago Souza
